<?php

namespace Database\Factories;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10),
            // Full-access role by default so feature tests exercise business logic, not permissions;
            // use reception()/withoutRole() to test restricted access.
            'role_id' => fn () => Role::query()->where('slug', 'gerant')->value('id'),
            'is_active' => true,
            'must_change_password' => false,
            // Existing tests target the full layout (sidebar + figures dashboard on /admin); the
            // simple mode is tested explicitly with ->simpleUi().
            'ui_mode' => 'complet',
        ];
    }

    public function simpleUi(): static
    {
        return $this->state(fn () => ['ui_mode' => 'simple']);
    }

    public function reception(): static
    {
        return $this->state(fn (array $attributes) => [
            'role_id' => Role::query()->where('slug', 'reception')->value('id'),
        ]);
    }

    public function withoutRole(): static
    {
        return $this->state(fn (array $attributes) => [
            'role_id' => null,
        ]);
    }

    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'is_active' => false,
        ]);
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }
}
